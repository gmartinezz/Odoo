# -*- coding: utf-8 -*-
##########################################################################
#
#    Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#
##########################################################################
from . import rest_api_resource
from . import rest_api
from . import odoo_http
from . import inherit_basemodel
